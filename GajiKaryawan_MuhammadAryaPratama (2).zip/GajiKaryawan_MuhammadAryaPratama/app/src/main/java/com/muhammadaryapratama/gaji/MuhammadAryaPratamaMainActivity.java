package com.muhammadaryapratama.gaji;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MuhammadAryaPratamaMainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.muhammadaryapratama_activity_main);

        View btnGaji = findViewById(R.id.MuhammadAryaPratamaBtnGaji);
        View btnPetunjuk = findViewById(R.id.MuhammadAryaPratamaBtnPetunjuk);
        View btnTentang = findViewById(R.id.MuhammadAryaPratamaBtnTentang);
        View btnExit = findViewById(R.id.MuhammadAryaPratamaBtnExit);

        btnGaji.setOnClickListener(v -> startActivity(new Intent(this, MuhammadAryaPratamaGajiActivity.class)));
        btnPetunjuk.setOnClickListener(v -> startActivity(new Intent(this, MuhammadAryaPratamaPetunjukActivity.class)));
        btnTentang.setOnClickListener(v -> startActivity(new Intent(this, MuhammadAryaPratamaTentangActivity.class)));
        btnExit.setOnClickListener(v -> konfirmasiKeluar());
    }

    private void konfirmasiKeluar() {
        new AlertDialog.Builder(this)
                .setTitle("Keluar")
                .setMessage("Yakin ingin keluar dari aplikasi?")
                .setPositiveButton("Ya", (d, w) -> finishAffinity())
                .setNegativeButton("Batal", null)
                .show();
    }
}
