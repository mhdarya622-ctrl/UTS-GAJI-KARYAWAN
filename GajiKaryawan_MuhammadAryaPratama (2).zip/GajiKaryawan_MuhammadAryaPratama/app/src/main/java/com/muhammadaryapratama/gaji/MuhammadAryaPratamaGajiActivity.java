package com.muhammadaryapratama.gaji;

import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.text.NumberFormat;
import java.util.Locale;

public class MuhammadAryaPratamaGajiActivity extends AppCompatActivity {

    private static final double TUNJANGAN_MAKAN_PER_HARI = 10000;
    private static final double TUNJANGAN_TRANSPORT_PER_HARI = 5000;
    private static final double PAJAK = 0.10;

    TextInputLayout tilNik, tilNama, tilGajiPokok, tilTunjJabatan, tilHariKerja;
    TextInputEditText etNik, etNama, etGajiPokok, etTunjJabatan, etHariKerja;
    View cardHasil;
    ScrollView scroll;
    TextView tvInfo, tvTunjMakan, tvTunjTransport, tvGajiKotor, tvPajak, tvGajiBersih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.muhammadaryapratama_activity_gaji);

        ((MaterialToolbar) findViewById(R.id.MuhammadAryaPratamaToolbarGaji)).setNavigationOnClickListener(v -> finish());

        scroll = findViewById(R.id.MuhammadAryaPratamaScrollGaji);
        tilNik = findViewById(R.id.MuhammadAryaPratamaTilNik);
        tilNama = findViewById(R.id.MuhammadAryaPratamaTilNama);
        tilGajiPokok = findViewById(R.id.MuhammadAryaPratamaTilGajiPokok);
        tilTunjJabatan = findViewById(R.id.MuhammadAryaPratamaTilTunjJabatan);
        tilHariKerja = findViewById(R.id.MuhammadAryaPratamaTilHariKerja);
        etNik = findViewById(R.id.MuhammadAryaPratamaEtNik);
        etNama = findViewById(R.id.MuhammadAryaPratamaEtNama);
        etGajiPokok = findViewById(R.id.MuhammadAryaPratamaEtGajiPokok);
        etTunjJabatan = findViewById(R.id.MuhammadAryaPratamaEtTunjJabatan);
        etHariKerja = findViewById(R.id.MuhammadAryaPratamaEtHariKerja);

        cardHasil = findViewById(R.id.MuhammadAryaPratamaCardHasil);
        tvInfo = findViewById(R.id.MuhammadAryaPratamaTvInfo);
        tvTunjMakan = findViewById(R.id.MuhammadAryaPratamaTvTunjMakan);
        tvTunjTransport = findViewById(R.id.MuhammadAryaPratamaTvTunjTransport);
        tvGajiKotor = findViewById(R.id.MuhammadAryaPratamaTvGajiKotor);
        tvPajak = findViewById(R.id.MuhammadAryaPratamaTvPajak);
        tvGajiBersih = findViewById(R.id.MuhammadAryaPratamaTvGajiBersih);

        findViewById(R.id.MuhammadAryaPratamaBtnHitung).setOnClickListener(v -> hitung());
        findViewById(R.id.MuhammadAryaPratamaBtnReset).setOnClickListener(v -> reset());
    }

    private boolean kosong(TextInputLayout til, TextInputEditText et) {
        if (et.getText() == null || et.getText().toString().trim().isEmpty()) {
            til.setError("Wajib diisi");
            return true;
        }
        til.setError(null);
        return false;
    }

    private void hitung() {
        boolean salah = false;
        salah |= kosong(tilNik, etNik);
        salah |= kosong(tilNama, etNama);
        salah |= kosong(tilGajiPokok, etGajiPokok);
        salah |= kosong(tilTunjJabatan, etTunjJabatan);
        salah |= kosong(tilHariKerja, etHariKerja);
        if (salah) {
            Toast.makeText(this, "Semua data harus diisi!", Toast.LENGTH_SHORT).show();
            return;
        }

        double gajiPokok, tunjJabatan;
        int hariKerja;
        try {
            gajiPokok = Double.parseDouble(etGajiPokok.getText().toString().trim());
            tunjJabatan = Double.parseDouble(etTunjJabatan.getText().toString().trim());
            hariKerja = Integer.parseInt(etHariKerja.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Input angka tidak valid", Toast.LENGTH_SHORT).show();
            return;
        }

        double tunjMakan = hariKerja * TUNJANGAN_MAKAN_PER_HARI;
        double tunjTransport = hariKerja * TUNJANGAN_TRANSPORT_PER_HARI;
        double gajiKotor = gajiPokok + tunjJabatan + tunjMakan + tunjTransport;
        double pajak = PAJAK * gajiKotor;
        double gajiBersih = gajiKotor - pajak;

        tvInfo.setText(etNama.getText().toString().trim() + "  •  NIK " + etNik.getText().toString().trim());
        tvTunjMakan.setText(rupiah(tunjMakan));
        tvTunjTransport.setText(rupiah(tunjTransport));
        tvGajiKotor.setText(rupiah(gajiKotor));
        tvPajak.setText("- " + rupiah(pajak));
        tvGajiBersih.setText(rupiah(gajiBersih));

        cardHasil.setVisibility(View.VISIBLE);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void reset() {
        etNik.setText("");
        etNama.setText("");
        etGajiPokok.setText("");
        etTunjJabatan.setText("");
        etHariKerja.setText("");
        tilNik.setError(null);
        tilNama.setError(null);
        tilGajiPokok.setError(null);
        tilTunjJabatan.setError(null);
        tilHariKerja.setError(null);
        cardHasil.setVisibility(View.GONE);
        etNik.requestFocus();
    }

    private String rupiah(double nilai) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        nf.setMaximumFractionDigits(0);
        return nf.format(nilai);
    }
}
