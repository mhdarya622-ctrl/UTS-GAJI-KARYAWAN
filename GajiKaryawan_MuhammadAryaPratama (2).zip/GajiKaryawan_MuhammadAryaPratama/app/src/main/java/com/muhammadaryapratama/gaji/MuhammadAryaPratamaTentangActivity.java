package com.muhammadaryapratama.gaji;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

public class MuhammadAryaPratamaTentangActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.muhammadaryapratama_activity_tentang);

        ((MaterialToolbar) findViewById(R.id.MuhammadAryaPratamaToolbarTentang)).setNavigationOnClickListener(v -> finish());
    }
}
